SMODS.Joker{ --Athelete
    key = "athelete",
    config = {
        extra = {
            levels = 4,
            most = 0
        }
    },
    loc_txt = {
        ['name'] = 'Athelete',
        ['text'] = {
            [1] = 'When a card with a {C:red}red{} seal is {C:red}destroyed{}',
            [2] = 'Upgrade your most played {C:blue}hand{} four times'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.remove_playing_cards and not context.blueprint then
            if (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card.seal == "Red" then
            return true
        end
    end
    return false
end)() then
                temp_played = 0
        temp_order = math.huge
        for hand, value in pairs(G.GAME.hands) do 
          if value.played > temp_played and value.visible then
            temp_played = value.played
            temp_order = value.order
            target_hand = hand
          else if value.played == temp_played and value.visible then
            if value.order < temp_order then
              temp_order = value.order
              target_hand = hand
            end
          end
          end
        end
                return {
                    level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                    message = Runner up!
                }
            end
        end
    end
}