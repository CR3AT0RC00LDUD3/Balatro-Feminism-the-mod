SMODS.Joker{ --Showomen
    key = "showomen",
    config = {
        extra = {
            dollars = 10
        }
    },
    loc_txt = {
        ['name'] = 'Showomen',
        ['text'] = {
            [1] = 'If you currently have {C:attention}5{}',
            [2] = '{C:attention}Jokers{} Or more',
            [3] = 'gain {C:attention}10${} after defeating the {C:attention}Boss Blind{}'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss and not context.blueprint then
            if #G.jokers.cards >= 5 then
                return {
                    dollars = card.ability.extra.dollars,
                    message = "Nice show!"
                }
            end
        end
    end
}