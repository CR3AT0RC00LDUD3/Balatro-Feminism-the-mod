SMODS.Joker{ --Baroness
    key = "Baroness_j",
    config = {
        extra = {
            Xmult = 3.5
        }
    },
    loc_txt = {
        ['name'] = 'Baroness',
        ['text'] = {
            [1] = 'Each scoring {C:attention}queen{} gives {X:red,C:white}X3.5{} mult'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if context.other_card:get_id() == 12 then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}